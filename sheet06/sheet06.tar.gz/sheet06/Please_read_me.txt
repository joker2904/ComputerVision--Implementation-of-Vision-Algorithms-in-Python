Manzil Roy	
Dhananjay R B	

We have uploaded the images for k=2 we didn't have enough time for k=3 for usps digits
For image segmentation wwe have done for k=1 and shown the output. Please consider this.
